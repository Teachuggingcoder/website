# To Do
|✅ | The thing to do |
|:-:|:----------------|
| | Custom mouse cursor |
|✅| Midi player |
|✅| Home page information |
| | Split gallery into sections: Photos + Desgin |
|✅| More gifs |
| | Finish building the 0day surprise function |
| | Make the gallery display full resolution images onClick |
|✅| Test the webhook with Maddy |
| | Get help from Horsie on dealing with github workflow |
| | Replace current github action with one that works
| ✅|| Set up old-school guestbook

